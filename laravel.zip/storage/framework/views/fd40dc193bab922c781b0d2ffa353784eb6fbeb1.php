

<?php $__env->startSection('title', 'Pendaftaran Baronas | Evolution 2021'); ?>

<?php $__env->startSection('container'); ?>

<!-- Header -->
<div class="header bg-default pb-6">
    <div class="container-fluid">
        <div class="header-body">
            <div class="row align-items-center py-4">
                <div class="col-lg-6 col-7">
                    <nav aria-label="breadcrumb" class="d-none d-md-inline-block ">
                        <ol class="breadcrumb breadcrumb-links breadcrumb-dark">
                            <li class="breadcrumb-item"><a><i class="fas fa-home" style="color: #172B4D"></i></a></li>
                            <li class="breadcrumb-item"><a style="color: #172B4D">Pendaftaran</a></li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Page content -->
<div class="container-fluid mt--6">
    <div class="row">
        <div class="col-12" style="width: 100%;">
            <div class="card" style="width: 100%;">
                <!-- <img src="/img/brand/ELECTRA.png" class="card-img-top p-2" alt="Logo Electra" style="width: 50%; margin: 0 auto;"> -->
                <div class="card-body">
                    <h5 class="card-title" style="font-size: xx-large; text-align: center;">
                        <img src="/img/brand/BARONAS_FULL.png" alt="">
                    </h5>

                    <div class="row">
                        <div class="col">
                            <div class="card">
                                <div class="card-body">
                                    <h6 class="heading text-muted mb-4">Pendaftaran Baronas</h6>
                                    <form method="GET">
                                        <div class="form-group">
                                            <label class="form-control-label" for="input-name">Nama Tim</label>
                                            <input type="text" id="nama-tim" class="form-control" placeholder="Nama Tim" value="">
                                        </div>
                                        <div class="form-group">
                                            <label class="form-control-label" for="input-name">Nama Ketua</label>
                                            <input type="text" id="nama-ketua" class="form-control" placeholder="Nama Lengkap" value="">
                                        </div>
                                        <div class="form-group">
                                            <label class="form-control-label" for="input-name">Kelas</label>
                                            <input type="text" id="kelas-ketua" class="form-control" placeholder="Kelas ( ketua )" value="">
                                        </div>
                                        <div class="form-group">
                                            <label class="form-control-label" for="input-name">Nama Anggota</label>
                                            <input type="text" id="nama-anggota" class="form-control" placeholder="Nama Lengkap" value="">
                                        </div>
                                        <div class="form-group">
                                            <label class="form-control-label" for="input-name">Kelas </label>
                                            <input type="text" id="kelas-anggota" class="form-control" placeholder="Kelas ( anggota )" value="">
                                        </div>
                                        <div class="form-group">
                                            <label class="form-control-label" for="input-name">Sekolah </label>
                                            <input type="text" id="sekolah" class="form-control" placeholder="Nama Sekolah" value="">
                                        </div>
                                        <div class="form-group">
                                            <label class="form-control-label" for="input-name">Alamat Sekolah </label>
                                            <input type="text" id="alamat-sekolah" class="form-control" placeholder="Alamat" value="">
                                        </div>
                                        <div class="form-group">
                                            <label class="form-control-label" for="input-email">Alamat Email</label>
                                            <input type="email" id="email-peserta" class="form-control" placeholder="Alamat Email untuk Pengiriman Sertifkat" value="">
                                        </div>
                                        <div class="form-group">
                                            <label class="form-control-label" for="input-phone">Nomor HP</label>
                                            <input type="text" id="nomor-hp" class="form-control" placeholder="Nomor HP" value="">
                                        </div>
                                        <button type="submit" value="daftar" class="btn text-lighter" style="width: 100%; background-color: #6EB648">Daftar</button>
                                        <hr class="my-4" />
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layout/template-user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Kuliah\Evolution\laravel\resources\views/user/form-baronas.blade.php ENDPATH**/ ?>