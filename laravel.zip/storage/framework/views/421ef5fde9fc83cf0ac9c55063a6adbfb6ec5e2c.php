<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Generate Email</title>
</head>

<body>
    <p>
        Terima Kasih tim <?php echo e($nama_tim); ?> atas pembayaran yang sudah dilakukan, berikut kuitansi atas pembayaran yang telah dilakukan. Persiapkan tim kalian karena kompetisi akan segera dimulai.
    </p>
</body>

</html><?php /**PATH E:\Kuliah\Evolution\laravel\resources\views/dokumen/email-layout.blade.php ENDPATH**/ ?>