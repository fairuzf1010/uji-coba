

<?php $__env->startSection('title', 'Daftar Peserta Electra | Evolution 2021'); ?>

<?php $__env->startSection('container'); ?>

<!-- Header -->
<div class="header bg-default pb-6">
    <div class="container-fluid">
        <div class="header-body">
            <div class="row align-items-center py-4">
                <div class="col-lg-6 col-7">
                    <nav aria-label="breadcrumb" class="d-none d-md-inline-block ">
                        <ol class="breadcrumb breadcrumb-links breadcrumb-dark">
                            <li class="breadcrumb-item"><a href="#"><i class="fas fa-home" style="color: #172B4D"></i></a></li>
                            <li class="breadcrumb-item"><a href="#" style="color: #172B4D">Daftar Peserta Electra</a></li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Page content -->
<div class="container-fluid mt--6">
    <div class="row">
        <div class="col-12" style="width: 100%;">
            <div class="card" style="width: 100%;">
                <!-- <img src="/img/brand/ELECTRA.png" class="card-img-top p-2" alt="Logo Electra" style="width: 50%; margin: 0 auto;"> -->
                <div class="card-body">
                    <h5 class="card-title" style="font-size: xx-large; text-align: center;">
                        <img src="/img/brand/ELECTRA_FULL.png" alt="">
                    </h5>

                    <div class="row">
                        <div class="col">
                            <?php if($notification = Session::get('email-fail')): ?>
                            <div class="alert alert-danger alert-block">
                                <strong><?php echo e($notification); ?></strong>
                            </div>
                            <?php endif; ?>
                            <!-- DataTales Example -->
                            <div class="card shadow mb-4">
                                <div class="card-body">
                                    <div class="table-responsive">
                                        <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                            <thead>
                                                <tr>
                                                    <th>Tim </th>
                                                    <th>Ketua</th>
                                                    <th>Region</th>
                                                    <th>Pembayaran</th>
                                                    <th>Tanggal Daftar</th>
                                                    <th>Aksi</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php $__currentLoopData = $list_electra; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $electra): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><?php echo e($electra->nama_tim); ?></td>
                                                    <td><?php echo e($electra->nama_ketua); ?></td>
                                                    <td>
                                                        <?php if($electra->region == ''): ?>
                                                        <span class="badge badge-pill badge-lg badge-success">Online</span>
                                                        <?php endif; ?>

                                                        <?php if($electra->region != ''): ?>
                                                        <span class="badge badge-pill badge-lg badge-warning"><?php echo e($electra->region); ?></span>
                                                        <?php endif; ?>
                                                    </td>
                                                    <td>

                                                        <?php if($electra->pembayaran_status == 0): ?>
                                                        <span class="badge badge-pill badge-lg badge-secondary">Menunggu pembayaran</span>
                                                        <?php endif; ?>

                                                        <?php if($electra->pembayaran_status == 1): ?>
                                                        <span class="badge badge-pill badge-lg badge-warning">Belum dikonfirmasi</span>
                                                        <?php endif; ?>

                                                        <?php if($electra->pembayaran_status == 2): ?>
                                                        <span class="badge badge-pill badge-lg badge-success">LUNAS</span>
                                                        <?php endif; ?>

                                                        <?php if($electra->pembayaran_status == 3): ?>
                                                        <span class="badge badge-pill badge-lg badge-primary">LANGSUNG</span>
                                                        <?php endif; ?>

                                                    </td>
                                                    <td><?php echo e($electra->created_at); ?></td>
                                                    <td style="text-align: center">
                                                        <?php if($electra->pembayaran_status == 1): ?>
                                                        <!-- Button trigger modal -->
                                                        <button type="button" class="btn btn-success btn-md" data-toggle="modal" data-target="#konfirmasi" onclick="konfirmasiModal(<?php echo e($electra->id); ?>, '<?php echo e($electra->pembayaran_bukti); ?>');">
                                                            Konfirmasi
                                                        </button>
                                                        <?php endif; ?>

                                                        <!-- Button trigger modal -->
                                                        <button type="button" class="btn btn-danger btn-md" data-toggle="modal" data-target="#hapus" onclick="hapusModal(<?php echo e($electra->id); ?>);">
                                                            Hapus
                                                        </button>

                                                    </td>
                                                </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>
                                    </div>

                                </div>
                            </div>


                        </div>
                    </div>


                </div>
            </div>
        </div>
    </div>



    <!-- Modal -->
    <div class="modal fade" id="konfirmasi" data-backdrop="static" data-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <!-- <div class="modal-header">
                <h5 class="modal-title" id="staticBackdropLabel">Evoulution 2021</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div> -->
                <div class="modal-body">
                    <h3 class="mt-3">Konfirmasi pembayaran peserta ?</h3>
                </div>
                <img id="gambarBuktiPembayaran" style="width:100%;" src="">
                <div class="modal-footer">
                    <a id="konfirmasiBtnFinal" href="" type="button" class="btn btn-success">Konfirmasi !</a>
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Tutup</button>
                </div>
            </div>
        </div>
    </div>
    <!-- Modal -->
    <div class="modal fade" id="hapus" data-backdrop="static" data-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <!-- <div class="modal-header">
                <h5 class="modal-title" id="staticBackdropLabel">Evoulution 2021</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div> -->
                <div class="modal-body">
                    <h3 class="mt-3">Hapus data peserta ?</h3>
                </div>
                <div class="modal-footer">
                    <a id="hapusBtnFinal" href="" type="button" class="btn btn-danger">Hapus !</a>
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Tutup</button>
                </div>
            </div>
        </div>
    </div>

    <script type="text/javascript">
        function konfirmasiModal(mHref, mSrc) {
            // alert(mSrc);
            document.getElementById("gambarBuktiPembayaran").src = "<?php echo e(url('/storage')); ?>/" + mSrc;
            document.getElementById("konfirmasiBtnFinal").href = "<?php echo e(url('/admin/list/electra/konfirmasi')); ?>/" + mHref;
        }

        function hapusModal(mHref) {
            document.getElementById("hapusBtnFinal").href = "<?php echo e(url('/admin/list/electra/delete')); ?>/" + mHref;
        }
    </script>

    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layout/template-admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Kuliah\Evolution\laravel\resources\views/admin/list-electra.blade.php ENDPATH**/ ?>