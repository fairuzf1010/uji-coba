

<?php $__env->startSection('title', 'Konfirmasi Peserta Electra | Evolution 2021'); ?>

<?php $__env->startSection('container'); ?>

<!-- Header -->
<div class="header bg-default pb-6">
    <div class="container-fluid">
        <div class="header-body">
            <div class="row align-items-center py-4">
                <div class="col-lg-6 col-7">
                    <nav aria-label="breadcrumb" class="d-none d-md-inline-block ">
                        <ol class="breadcrumb breadcrumb-links breadcrumb-dark">
                            <li class="breadcrumb-item"><a href="#"><i class="fas fa-home" style="color: #172B4D"></i></a></li>
                            <li class="breadcrumb-item"><a href="#" style="color: #172B4D">Konfirmasi Peserta Electra</a></li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Page content -->
<div class="container-fluid mt--6">
    <div class="row">
        <div class="col-12" style="width: 100%;">
            <div class="card" style="width: 100%;">
                <!-- <img src="/img/brand/ELECTRA.png" class="card-img-top p-2" alt="Logo Electra" style="width: 50%; margin: 0 auto;"> -->
                <div class="card-body">
                    <h5 class="card-title" style="font-size: xx-large; text-align: center;">
                        <img src="/img/brand/ELECTRA_FULL.png" alt="">
                    </h5>

                    <div class="row">
                        <div class="col">
                            <!-- DataTales Example -->
                            <div class="card shadow mb-4">
                                <div class="card-body">
                                    <div class="table-responsive">
                                        <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                            <thead>
                                                <tr>
                                                    <th>No </th>
                                                    <th>Nama Ketua</th>
                                                    <th>Nama Tim</th>
                                                    <th>Tanggal Daftar</th>
                                                    <th>No Rekening</th>
                                                    <th>Bukti Pembayaran</th>
                                                    <th>Aksi</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <tr>
                                                    <td>1</td>
                                                    <td>Tiger Nixon</td>
                                                    <td>System Architect</td>
                                                    <td>2011/04/25</td>
                                                    <td>874393187</td>
                                                    <td>Edinburgh</td>
                                                    <td style="text-align: center"> <a href="#!" class="btn bg-success btn-sm" style="color: white; font-size: 15px;">Konfirmasi</a>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>2</td>
                                                    <td>Garrett Winters</td>
                                                    <td>Accountant</td>
                                                    <td>2011/04/25</td>
                                                    <td>874393187</td>
                                                    <td>Edinburgh</td>
                                                    <td style="text-align: center"> <a href="#!" class="btn bg-success btn-sm" style="color: white; font-size: 15px;">Konfirmasi</a>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>3</td>
                                                    <td>Ashton Cox</td>
                                                    <td>Junior Technical Author</td>
                                                    <td>2011/04/25</td>
                                                    <td>874393187</td>
                                                    <td>Edinburgh</td>
                                                    <td style="text-align: center"> <a href="#!" class="btn bg-success btn-sm" style="color: white; font-size: 15px;">Konfirmasi</a>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>4</td>
                                                    <td>Cedric Kelly</td>
                                                    <td>Senior Javascript Developer</td>
                                                    <td>2011/04/25</td>
                                                    <td>874393187</td>
                                                    <td>Edinburgh</td>
                                                    <td style="text-align: center"> <a href="#!" class="btn bg-success btn-sm" style="color: white; font-size: 15px;">Konfirmasi</a>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>5</td>
                                                    <td>Airi Satou</td>
                                                    <td>Accountant</td>
                                                    <td>2011/04/25</td>
                                                    <td>874393187</td>
                                                    <td>Edinburgh</td>
                                                    <td style="text-align: center"> <a href="#!" class="btn bg-success btn-sm" style="color: white; font-size: 15px;">Konfirmasi</a>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>6</td>
                                                    <td>Brielle Williamson</td>
                                                    <td>Integration Specialist</td>
                                                    <td>2011/04/25</td>
                                                    <td>874393187</td>
                                                    <td>Edinburgh</td>
                                                    <td style="text-align: center"> <a href="#!" class="btn bg-success btn-sm" style="color: white; font-size: 15px;">Konfirmasi</a>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>7</td>
                                                    <td>Herrod Chandler</td>
                                                    <td>Sales Assistant</td>
                                                    <td>2011/04/25</td>
                                                    <td>874393187</td>
                                                    <td>Edinburgh</td>
                                                    <td style="text-align: center"> <a href="#!" class="btn bg-success btn-sm" style="color: white; font-size: 15px;">Konfirmasi</a>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>8</td>
                                                    <td>Rhona Davidson</td>
                                                    <td>Integration Specialist</td>
                                                    <td>2011/04/25</td>
                                                    <td>874393187</td>
                                                    <td>Edinburgh</td>
                                                    <td style="text-align: center"> <a href="#!" class="btn bg-success btn-sm" style="color: white; font-size: 15px;">Konfirmasi</a>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>9</td>
                                                    <td>Colleen Hurst</td>
                                                    <td>Javascript Developer</td>
                                                    <td>2011/04/25</td>
                                                    <td>874393187</td>
                                                    <td>Edinburgh</td>
                                                    <td style="text-align: center"> <a href="#!" class="btn bg-success btn-sm" style="color: white; font-size: 15px;">Konfirmasi</a>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>10</td>
                                                    <td>Sonya Frost</td>
                                                    <td>Software Engineer</td>
                                                    <td>2011/04/25</td>
                                                    <td>874393187</td>
                                                    <td>Edinburgh</td>
                                                    <td style="text-align: center"> <a href="#!" class="btn bg-success btn-sm" style="color: white; font-size: 15px;">Konfirmasi</a>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>11</td>
                                                    <td>Jena Gaines</td>
                                                    <td>Office Manager</td>
                                                    <td>2011/04/25</td>
                                                    <td>874393187</td>
                                                    <td>Edinburgh</td>
                                                    <td style="text-align: center"> <a href="#!" class="btn bg-success btn-sm" style="color: white; font-size: 15px;">Konfirmasi</a>
                                                    </td>
                                                </tr>

                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>

                            <a href="<?php echo e(url('/admin/pembayaran')); ?>" class="btn" style="color: white; font-size: 15px; background-color: #707CAA">Kembali</a>
                        </div>
                    </div>


                </div>
            </div>
        </div>
    </div>


    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layout/template-admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Kuliah\Evolution\laravel\resources\views/admin/list-pembayaran-electra.blade.php ENDPATH**/ ?>