

<?php $__env->startSection('title', 'Selamat Datang | Evolution 2021'); ?>

<?php $__env->startSection('container'); ?>

<!-- Header -->
<div class="header pb-6 d-flex align-items-center" style="min-height: 500px; background-image: url(/img/theme/hero.jpeg); background-size: cover; background-position: center top;">
    <!-- Mask -->
    <span class="mask bg-gradient-default opacity-8"></span>
    <!-- Header container -->
    <div class="container-fluid d-flex align-items-center">
        <div class="row">
            <div class="col-lg-7 col-md-10">
                <h1 class="display-2 text-white mb-5" style="font-size: 50px">SELAMAT DATANG DI EVOLUTION 2021</h1>

            </div>
        </div>
    </div>
</div>
<!-- Page content -->
<div class="container-fluid mt--6">
    <div class="row">
        <div class="col">
            <div class="card">
                <!-- Card header -->
                <div class="card-header border-0">
                    <h1 class="mb-0">PENGUMUMAN</h1>
                </div>
                <!-- Light table -->
                <div class="table-responsive">
                    <table class="table align-items-center ">
                        <div class="media-body p-3">
                            <span class="name mb-0 text-sm" style="text-align: justify;">Lorem ipsum dolor sit, amet consectetur adipisicing elit. Voluptas impedit eius ipsum maiores officiis eos consequuntur culpa soluta eligendi iure, excepturi, sint repudiandae pariatur quidem laudantium cumque, ducimus itaque autem! Lorem ipsum dolor, sit amet consectetur adipisicing elit. Quidem ut deleniti voluptatibus laudantium deserunt vel! Necessitatibus in dolorem quo ipsam, quam voluptatem non vel officiis ut aut accusamus amet esse.</span>
                        </div>
                    </table>
                </div>

            </div>
        </div>
    </div>

    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layout/template-user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Kuliah\Evolution\laravel\resources\views/user/dashboard.blade.php ENDPATH**/ ?>