<!DOCTYPE html>
<!-- saved from url=(0031)https://www.vultr.com/register/ -->
<html>

<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0, viewport-fit=cover">
	<title>Login - EVOLUTION ITS</title>
	<meta name="keywords" content="">
	<meta name="description" content="">

	<!-- Fix chrome language detection -->

	<meta http-equiv="Content-Language" content="en">

	<!-- Favicons -->
	<link rel="icon" href="/img/brand/favicon.png" type="image/png">

	<!-- Styles -->
	<link href="css/style.css" rel="stylesheet">

	<!--[if lt IE 9]>
	<script src="/dist/js/selectivizr-min.js"></script>
	<script src="/dist/js/html5shiv.min.js"></script>
	<script src="/dist/js/respond.min.js"></script>
	<![endif]-->
	<div style="width: 1px; height: 1px; display: inline; position: absolute;"><img height="1" width="1" style="border-style:none;" alt="" src="css/out">
		<img height="1" width="1" style="border-style:none;" alt="" src="css/out(1)"><img height="1" width="1" style="border-style:none;" alt="" src="css/out(2)">
		<img height="1" width="1" style="border-style:none;" alt="" src="css/out(3)"><img height="1" width="1" style="border-style:none;" alt="" src="css/out(4)">
		<img height="1" width="1" style="border-style:none;" alt="" src="css/out(5)"><img height="1" width="1" style="border-style:none;" alt="" src="css/out(6)">
		<img height="1" width="1" style="border-style:none;" alt="" src="css/out(7)"></div>
	<div style="width: 1px; height: 1px; display: inline; position: absolute;">
		<img height="1" width="1" style="border-style:none;" alt="" src="css/out(5)">
		<img height="1" width="1" style="border-style:none;" alt="" src="css/out(8)">
		<img height="1" width="1" style="border-style:none;" alt="" src="css/out(9)">
		<img height="1" width="1" style="border-style:none;" alt="" src="css/out(10)">
		<img height="1" width="1" style="border-style:none;" alt="" src="css/out(11)">
		<img height="1" width="1" style="border-style:none;" alt="" src="css/out(12)">
	</div>
</head>

<body class="">
	<div class="sites site--full" style="background: linear-gradient(-135deg, #040429, #040429, #040429, #040429, #040429, #040429, #D3247B);">
		<header class="site-banner banner--shape banner banner--fullpage">
			<div class="container">
				<div class="banner__brand">
					<a href="{{url('/')}}" style="z-index: 99;">
						<img src="img/brand/EVOLUTION.png" alt="">
					</a>
				</div>


				<div class="banner__content  animation-element " data-animation="" data-animation-options="type:fadeInTop;" style="transform: translateY(0px); opacity: 1;">
					<div class="m-w-xs m-h-a">
						<div class="box box--auth" style="background-color: #181850;">
							<div class="box__content">
								<h1 class="box__title h2" style="color: white;">Selamat Datang</h1>

								@if ($notification = Session::get('failed'))
								<div class="alert alert-success alert-block">
									<strong>{{ $notification }}</strong>
								</div>
								@endif

								<form action="{{ route('user.login') }}" method="post" class="form" id="register-form" data-ps-strength="">
									@csrf

									<div class="form-group input-group" style="background-color: #595982;">
										<!-- logo email  -->
										<span class="input-group__icon"><svg class="icon-ui icon-ui--24" xmlns="http://www.w3.org/2000/svg" x="0px" y="0px" viewBox="0 0 24 24">
												<path class="stroke" d="M2,4h20v16H2V4z"></path>
												<path class="stroke" d="M2,8l10,5l10-5"></path>
											</svg>
										</span>
										<input name="email" value="" class="form-control" type="email" placeholder="Email Address" required="">
									</div>

									<div class="form-group input-group input-group--password-strength" style="background-color: #595982;">
										<!-- logo password  -->
										<span class="input-group__icon m-l-2x"><svg class="icon-ui icon-ui--24" xmlns="http://www.w3.org/2000/svg" x="0px" y="0px" viewBox="0 0 24 24">
												<path class="fill" d="M19,8V7c0-3.9-3.1-7-7-7S5,3.1,5,7v1h2V7c0-2.8,2.2-5,5-5s5,2.2,5,5v1H19"></path>
												<path class="stroke" d="M3,9h18v14H3V9z"></path>
												<circle class="fill" cx="8" cy="16" r="1"></circle>
												<circle class="fill" cx="12" cy="16" r="1"></circle>
												<circle class="fill" cx="16" cy="16" r="1"></circle>
											</svg>
										</span>
										<input name="password" class="form-control" type="password" placeholder="Password" required="" data-ps-strength-input="">
										<!-- <div class="input-group__password-addon">
											<div class="password-strength" data-ps-strength-progress="">
												<span class="password-strength__value"></span>
											</div>
										</div> -->
									</div>
									<hr class="hr15">
									<div class="form__actions">
										<button id="register_submit_button" type="submit" class="btn btn--primary btn--block" style="background-color: #D3247B; color: white"><span class="btn__text">Masuk</span><span class="btn-hover-effect"></span></button>
									</div>
								</form>
							</div>
						</div>
						<br>
						<div class="p-3 text-center m-b-0">Belum punya akun ? <a style="font-weight:bold; color: #D3247B" href="{{url('/register')}}">Daftar</a></div>
					</div>

				</div>
			</div>

			<!-- <div class="banner__background">

				<div class="banner__illustration illustration illustration--wide" data-animation="" data-animation-options="type:mainIllustration;">

					<div class="illustration__left-element">

						<svg class="svg-illustration svg-illustration--ssd animation-element" data-animation-ssd="" version="1.1" xmlns="http://www.w3.org/2000/svg" x="0px" y="0px" viewBox="0 0 182 130" style="transform: translateY(0px); opacity: 1;">
							<path class="gradient-1" d="M0,53.4h182v25.2c0,2.8-1.9,5.6-5.6,7.7l-36,20.5l-36,20.5c-8.5,4.2-18.5,4.2-27,0l-4.5-2.6L10.1,88.8l-4.5-2.6C1.9,84.1,0,81.3,0,78.6V53.4z"></path>
							<path class="fill-dark-blue-1 opacity-3" d="M13.3,75.6c-1.9-1.1-3.4-0.2-3.4,1.9v10.8l63.3,36.3v-10.8c-0.1-2.4-1.4-4.5-3.4-5.8L13.3,75.6z"></path>
							<path class="gradient-2" d="M176.4,60.1c3.7-2.1,5.6-5,5.6-7.8s-1.9-5.6-5.6-7.8l-36-20.7l-36-20.7c-8.5-4.3-18.5-4.3-27,0l-36,20.7l-36,20.7c-3.7,2.1-5.6,5-5.6,7.8s1.9,5.6,5.6,7.8l36,20.7l36,20.7c8.5,4.3,18.5,4.3,27,0l36-20.7	L176.4,60.1z"></path>
							<lineargradient id="gradient-ssd-1" gradientUnits="userSpaceOnUse" x1="0" y1="91.8999" x2="181.98" y2="91.8999">
								<stop offset="0" style="stop-color:#1D53DA"></stop>
								<stop offset="1" style="stop-color:#3F75FC"></stop>
							</lineargradient>
							<lineargradient id="gradient-ssd-2" gradientUnits="userSpaceOnUse" x1="0" y1="52.3752" x2="181.98" y2="52.3752">
								<stop offset="0" style="stop-color:#0397F6"></stop>
								<stop offset="1" style="stop-color:#00BAFF"></stop>
							</lineargradient>
						</svg>

						<div class="illustration__light animation-element" data-animation-light="" style="opacity: 1;">
							<svg class="svg-illustration svg-illustration-light" xmlns="http://www.w3.org/2000/svg" x="0px" y="0px" viewBox="0 0 182 274">
								<g class="svg-light">
									<path class="svg-light__1" d="M181.9,181.5c-0.3,2.6-2.1,5.1-5.5,7l-35.9,20.6l-35.9,20.6c-8.5,4.3-18.5,4.3-26.9,0l-35.9-20.6L5.9,188.5c-3.1-1.8-4.9-4.1-5.4-6.4H0V34h182l0,147.4L181.9,181.5L181.9,181.5z"></path>
									<path class="svg-light__2" d="M181.9,180.2c0,0.2,0,0.4,0,0.6c0,2.8-1.9,5.6-5.6,7.7l-71.8,41.2c-8.5,4.3-18.5,4.3-26.9,0L5.9,188.5c-3.5-2-5.4-4.6-5.5-7.3H0.3L0,0h182L181.9,180.2z"></path>
									<path class="svg-light__reflect" d="M0,274v-93.2c0,2.8,1.9,5.6,5.6,7.7l35.9,20.6l35.9,20.6c8.5,4.3,18.5,4.3,26.9,0l35.9-20.6l35.9-20.6c3.7-2.1,5.6-4.9,5.6-7.7c0-0.5-0.1-0.9-0.2-1.4h0.6v94L0,274z M0,180.8v-1.4h0.2C0.1,179.8,0,180.3,0,180.8z"></path>
								</g>
								<defs>
									<lineargradient id="svg-gradient__light-1" gradientUnits="userSpaceOnUse" x1="91.005" y1="232.879" x2="91.005" y2="34.043">
										<stop offset="0" style="stop-color:#17BDFF"></stop>
										<stop offset="0.8" style="stop-color:#17BDFF;stop-opacity:0"></stop>
									</lineargradient>
									<lineargradient id="svg-gradient__light-2" gradientUnits="userSpaceOnUse" x1="91" y1="232.876" x2="91" y2="-9.094947e-13">
										<stop offset="0" style="stop-color:#51B9FF"></stop>
										<stop offset="0.7" style="stop-color:#2389F0;stop-opacity:0.7"></stop>
										<stop offset="1" style="stop-color:#2389F0;stop-opacity:0"></stop>
									</lineargradient>
									<lineargradient id="svg-gradient__light-reflect" gradientUnits="userSpaceOnUse" x1="91.005" y1="179.391" x2="91.005" y2="274.009">
										<stop offset="0" style="stop-color:#17BDFF"></stop>
										<stop offset="0.8" style="stop-color:#17BDFF;stop-opacity:0"></stop>
									</lineargradient>
								</defs>
							</svg>
						</div>

					</div>

					<div class="illustration__right-element">
						<svg class="svg-illustration svg-illustration--ssd animation-element" data-animation-ssd="" version="1.1" xmlns="http://www.w3.org/2000/svg" x="0px" y="0px" viewBox="0 0 182 130" style="transform: translateY(0px); opacity: 1;">
							<path class="gradient-1" d="M0,53.4h182v25.2c0,2.8-1.9,5.6-5.6,7.7l-36,20.5l-36,20.5c-8.5,4.2-18.5,4.2-27,0l-4.5-2.6L10.1,88.8l-4.5-2.6C1.9,84.1,0,81.3,0,78.6V53.4z"></path>
							<path class="fill-dark-blue-1 opacity-3" d="M13.3,75.6c-1.9-1.1-3.4-0.2-3.4,1.9v10.8l63.3,36.3v-10.8c-0.1-2.4-1.4-4.5-3.4-5.8L13.3,75.6z"></path>
							<path class="gradient-2" d="M176.4,60.1c3.7-2.1,5.6-5,5.6-7.8s-1.9-5.6-5.6-7.8l-36-20.7l-36-20.7c-8.5-4.3-18.5-4.3-27,0l-36,20.7l-36,20.7c-3.7,2.1-5.6,5-5.6,7.8s1.9,5.6,5.6,7.8l36,20.7l36,20.7c8.5,4.3,18.5,4.3,27,0l36-20.7	L176.4,60.1z"></path>
							<lineargradient id="gradient-ssd-1" gradientUnits="userSpaceOnUse" x1="0" y1="91.8999" x2="181.98" y2="91.8999">
								<stop offset="0" style="stop-color:#1D53DA"></stop>
								<stop offset="1" style="stop-color:#3F75FC"></stop>
							</lineargradient>
							<lineargradient id="gradient-ssd-2" gradientUnits="userSpaceOnUse" x1="0" y1="52.3752" x2="181.98" y2="52.3752">
								<stop offset="0" style="stop-color:#0397F6"></stop>
								<stop offset="1" style="stop-color:#00BAFF"></stop>
							</lineargradient>
						</svg>

						<div class="illustration__light animation-element" data-animation-light="" style="opacity: 1;">
							<svg class="svg-illustration svg-illustration-light" xmlns="http://www.w3.org/2000/svg" x="0px" y="0px" viewBox="0 0 182 274">
								<g class="svg-light">
									<path class="svg-light__1" d="M181.9,181.5c-0.3,2.6-2.1,5.1-5.5,7l-35.9,20.6l-35.9,20.6c-8.5,4.3-18.5,4.3-26.9,0l-35.9-20.6L5.9,188.5c-3.1-1.8-4.9-4.1-5.4-6.4H0V34h182l0,147.4L181.9,181.5L181.9,181.5z"></path>
									<path class="svg-light__2" d="M181.9,180.2c0,0.2,0,0.4,0,0.6c0,2.8-1.9,5.6-5.6,7.7l-71.8,41.2c-8.5,4.3-18.5,4.3-26.9,0L5.9,188.5c-3.5-2-5.4-4.6-5.5-7.3H0.3L0,0h182L181.9,180.2z"></path>
									<path class="svg-light__reflect" d="M0,274v-93.2c0,2.8,1.9,5.6,5.6,7.7l35.9,20.6l35.9,20.6c8.5,4.3,18.5,4.3,26.9,0l35.9-20.6l35.9-20.6c3.7-2.1,5.6-4.9,5.6-7.7c0-0.5-0.1-0.9-0.2-1.4h0.6v94L0,274z M0,180.8v-1.4h0.2C0.1,179.8,0,180.3,0,180.8z"></path>
								</g>
								<defs>
									<lineargradient id="svg-gradient__light-1" gradientUnits="userSpaceOnUse" x1="91.005" y1="232.879" x2="91.005" y2="34.043">
										<stop offset="0" style="stop-color:#17BDFF"></stop>
										<stop offset="0.8" style="stop-color:#17BDFF;stop-opacity:0"></stop>
									</lineargradient>
									<lineargradient id="svg-gradient__light-2" gradientUnits="userSpaceOnUse" x1="91" y1="232.876" x2="91" y2="-9.094947e-13">
										<stop offset="0" style="stop-color:#51B9FF"></stop>
										<stop offset="0.7" style="stop-color:#2389F0;stop-opacity:0.7"></stop>
										<stop offset="1" style="stop-color:#2389F0;stop-opacity:0"></stop>
									</lineargradient>
									<lineargradient id="svg-gradient__light-reflect" gradientUnits="userSpaceOnUse" x1="91.005" y1="179.391" x2="91.005" y2="274.009">
										<stop offset="0" style="stop-color:#17BDFF"></stop>
										<stop offset="0.8" style="stop-color:#17BDFF;stop-opacity:0"></stop>
									</lineargradient>
								</defs>
							</svg>
						</div>

					</div>

				</div>
				<svg class="segitiga" x="0px" y="0px" viewBox="0 0 1903 556">
					<path class="svg-banner-shape" d="M753.1,434.2c110.6,63.7,277.7,70.6,373.4,15.4L1905,0v555.9H0V0.2L753.1,434.2z"></path>
				</svg>

			</div> -->
		</header>
	</div>
	<script src="css/jquery-3.5.1.min.js.download"></script>
	<script src="css/vendor.js.download"></script>
	<script src="css/main.js.download"></script>
	<script src="css/lazyload.min.js.download"></script>
	<script src="css/md5.min.js.download"></script>
	<script src="css/logo-animation.js.download"></script>