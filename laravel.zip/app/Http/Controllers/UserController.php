<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;

use App\User;
use App\Electra;
use Mail;

class UserController extends Controller
{
    public function submitBuktiPembayaran(Request $request)
    {
        $uploaded_filename = $request->file_bukti->store('public');
        $uploaded_filename = str_replace("public/", "", $uploaded_filename);

        $electra = Electra::where("email", "=", Auth::user()->email)->first();

        $electra->pembayaran_bank       = $request->bank_tujuan;
        $electra->pembayaran_atas_nama  = $request->nama_pengirim;
        $electra->pembayaran_status     = 1; //Sudah disubmit peserta, belum dikonfirmasi oleh admin
        $electra->pembayaran_bukti      = $uploaded_filename;
        $electra->save();

        return redirect('/user/pembayaran');
    }

    public function userPembayaran(Request $request)
    {
        $electra = Electra::where("email", "=", Auth::user()->email)->first();

        if ($electra == null)
            $electra = new Electra;

        return view('user.pembayaran', compact('electra'));
    }

    public function listElectraKonfirmasi($id)
    {
        $electra = Electra::find($id);
        $electra->pembayaran_status = 2;
        $electra->save();

        $data_target = DB::table('electras')->where('id', $id)->first();

        // genegrate nomor register ke kuitansi
        $nomor_peserta = $data_target->id;
        $syarat = $nomor_peserta / 10;
        if ($syarat < 1) {
            // 1 sampai 9
            $a = 0;
            $b = 0;
            $c = 0;
            $d = substr($nomor_peserta, 0, 1);
        } else if ($syarat < 10 && $syarat >= 1) {
            // 10 sampai 99
            $a = 0;
            $b = 0;
            $c = substr($nomor_peserta, 0, 1);
            $d = substr($nomor_peserta, 1, 1);
        } else if ($syarat >= 10 && $syarat < 100) {
            // 100 sampai 999
            $a = 0;
            $b = substr($nomor_peserta, 0, 1);
            $c = substr($nomor_peserta, 1, 1);
            $d = substr($nomor_peserta, 2, 1);
        } else if ($syarat >= 100) {
            // 1000 sampai 9999
            $a = substr($nomor_peserta, 0, 1);
            $b = substr($nomor_peserta, 1, 1);
            $c = substr($nomor_peserta, 2, 1);
            $d = substr($nomor_peserta, 3, 1);
        }

        $biaya = '60.000';
        $email = $data_target->email;
        $data = array(
            'nama_tim' => $data_target->nama_tim,
            'nama_ketua' => $data_target->nama_ketua,
            'nama_anggota' => $data_target->nama_anggota,
            'biaya' => $biaya,
            'digit_pertama' => $a,
            'digit_kedua' => $b,
            'digit_ketiga' => $c,
            'digit_keempat' => $d,
        );

        $pdf = \PDF::loadView('dokumen.invoice-layout', $data)->setPaper('a5', 'landscape');

        Mail::send('dokumen.email-layout', $data, function ($message) use ($email, $pdf) {

            $message->to($email, $email)
                ->subject('KONFIRMASI PEMBAYARAN EVOLUTION ELECTRA 2021')
                ->attachData($pdf->output(), "kuitansi.pdf");
            $message->from('hiitaufik24@gmail.com');
        });

        // jika gagal
        if (Mail::failures())
            return redirect('/admin/list/electra')->with('email-fail', 'Email gagal dikirim');

        else
            return redirect('/admin/list/electra');
    }

    public function kartuPeserta()
    {
        $electra = Electra::where("email", "=", Auth::user()->email)->first();
        $data = array(
            'status' => $electra->pembayaran_status
        );

        return view('/user/kartu', $data);
    }

    public function unduhKartu()
    {
        // ambil data berdasarkan id
        $electra = Electra::where("email", "=", Auth::user()->email)->first();
        $data = array(
            'nama_ketua' => $electra->nama_ketua,
            'nama_anggota' => $electra->nama_anggota,
            'nama_tim' => $electra->nama_tim,
            'sekolah' => $electra->sekolah
        );

        $pdf = \PDF::loadView('dokumen.kartu-peserta-layout', $data)->setPaper('a5', 'potrait');
        return $pdf->download('kartu-peserta.pdf');
    }

    public function listElectraDelete($id)
    {
        $electra = Electra::find($id);
        $electra->delete();

        $user = User::where("email", "=", $electra->email)->first();
        $user->delete();

        return redirect('/admin/list/electra')->with('success', 'Data peserta telah dihapus');
    }


    public function listElectra(Request $request)
    {
        $list_electra = DB::table('electras')->get();
        return view('admin.list-electra', ['list_electra' => $list_electra]);
    }

    public function formElectra(Request $request)
    {
        $electra = Electra::where("email", "=", Auth::user()->email)->first();

        if ($electra == null)
            $electra = new Electra;

        return view('user.form-electra', compact('electra'));
    }

    public function daftarElectra(Request $request)
    {
        $daftar = new Electra;
        $daftar->email              = Auth::user()->email;
        $daftar->nama_tim           = $request->nama_tim;
        $daftar->nama_ketua         = $request->nama_ketua;
        $daftar->kelas_ketua        = $request->kelas_ketua;
        $daftar->nama_anggota       = $request->nama_anggota;
        $daftar->kelas_anggota      = $request->kelas_anggota;
        $daftar->sekolah            = $request->sekolah;
        $daftar->alamat_sekolah     = $request->alamat_sekolah;
        $daftar->nomor_hp           = $request->nomor_hp;
        $daftar->pembayaran_status  = 0;
        $daftar->file_ktp_ketua     = $request->file_ktp_ketua->store('public');
        $daftar->file_ktp_anggota   = $request->file_ktp_anggota->store('public');
        $daftar->save();

        return redirect('/user/daftar/electra');
    }

    public function daftarElectraAdmin(Request $request)
    {
        if (Auth::user()->email == 'evolutionelektroits@gmail.com') {
            // User register rules
            $rules = array('email' => 'required|email|unique:users,email', 'password' => 'required|min:8');

            $input['email'] = $request->email;
            $input['password'] = "evolution123";
            $validator = Validator::make($input, $rules);

            if ($validator->fails()) {
                return redirect('/admin/tambah')->with('failed', $request->email);
            } else {
                // Register the new user
                User::create([
                    'email' => $request->email,
                    'password' => Hash::make($input['password']),
                ]);
            }

            $daftar = new Electra;

            $daftar->email              = $request->email;
            $daftar->nama_tim           = $request->nama_tim;
            $daftar->nama_ketua         = $request->nama_ketua;
            $daftar->kelas_ketua        = $request->kelas_ketua;
            $daftar->nama_anggota       = $request->nama_anggota;
            $daftar->kelas_anggota      = $request->kelas_anggota;
            $daftar->sekolah            = $request->sekolah;
            $daftar->alamat_sekolah     = $request->alamat_sekolah;
            $daftar->nomor_hp           = $request->nomor_hp;
            $daftar->region             = $request->region;
            $daftar->pembayaran_status  = 3; // register via korlap dan sudah lunas
            $daftar->file_ktp_ketua     = $request->file_ktp_ketua->store('public');
            $daftar->file_ktp_anggota   = $request->file_ktp_anggota->store('public');
            $daftar->save();

            return redirect('/admin/tambah')->with('success', $request->nama_tim);
        }
    }

    public function register(Request $request)
    {
        $input['email'] = $request->email;
        $input['password'] = $request->password;

        // User register rules
        $rules = array('email' => 'required|email|unique:users,email', 'password' => 'required|min:8');

        $validator = Validator::make($input, $rules);

        if ($validator->fails()) {
            return redirect('/register')->with('failed', 'Email telah terdaftar');
        } else {
            // Register the new user
            User::create([
                'email' => $request->email,
                'password' => Hash::make($request->password),
            ]);
            return redirect('/register')->with('success', 'Akun anda telah berhasil didaftarkan');
        }
    }

    public function updatePassword(Request $request)
    {
        if (Auth::user()) {

            // ambil data berdasarkan id
            $user = User::find(Auth::user()->id);

            // simpan form ke dalam variabel baru
            $passLama = $request->passwordLama;
            $passBaru = $request->passwordBaru;
            $passBaruKonfirmasi = $request->konfirmasiPasswordBaru;

            // cek apakah password lama sama atau tidak
            if (Hash::check($passLama, $user->password)) {

                // cek apakah password baru sama atau tidak
                if ($passBaru != $passBaruKonfirmasi) {
                    return redirect('/user/akun')->with('failed-baru', 'Password baru tidak sama');
                } else {
                    // ganti password
                    $request->user()->fill([
                        'password' => Hash::make($request->passwordBaru)
                    ])->save();

                    return redirect('/user/akun')->with('success', 'Password berhasil diganti');
                }
            } else {

                return redirect('/user/akun')->with('failed-lama', 'Password lama tidak sesuai');
            }
        }
    }

    public function login(Request $request)
    {
        $credentials = $request->only('email', 'password');

        if (Auth::attempt($credentials)) {
            // Authentication passed...
            if (Auth::user()->email == 'evolutionelektroits@gmail.com')
                return redirect('/admin/dashboard');
            else
                return redirect('/user/dashboard');
        }

        return redirect('/login')->with('failed', 'Email atau Password salah');
    }

    public function logout(Request $request)
    {
        $request->session()->flush();
        return redirect('/login');
    }
}
