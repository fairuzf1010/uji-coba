<?php

header(‘Location: public/’);