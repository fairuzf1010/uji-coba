<?php

namespace Thomasjohnkane\Snooze\Exception;

class SendingFailedException extends LaravelSnoozeException
{
}
