<?php

namespace Thomasjohnkane\Snooze\Exception;

class NotificationCancelledException extends LaravelSnoozeException
{
}
