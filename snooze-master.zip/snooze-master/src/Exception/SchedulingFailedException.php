<?php

namespace Thomasjohnkane\Snooze\Exception;

class SchedulingFailedException extends LaravelSnoozeException
{
}
