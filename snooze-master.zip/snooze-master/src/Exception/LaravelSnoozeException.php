<?php

namespace Thomasjohnkane\Snooze\Exception;

class LaravelSnoozeException extends \Exception
{
}
