<?php

namespace Thomasjohnkane\Snooze\Exception;

class NotificationAlreadySentException extends LaravelSnoozeException
{
}
