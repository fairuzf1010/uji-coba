<?php

namespace Thomasjohnkane\Snooze;

class Snooze
{
}
